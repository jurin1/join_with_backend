export const STORAGE_TOKEN = "Y2B64H33P1ZFHWE7S0HF0V8EC9OTCQZV1FG8B8B5";
export const STORAGE_URL = "https://remote-storage.developerakademie.org/item";
